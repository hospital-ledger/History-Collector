#!/bin/bash

if [ -d "/opt/cache" ]; then
    rm -f -r /opt/cache
fi