# This sctipt is provided for CentOS 7.
